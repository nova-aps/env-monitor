Grove_barometer HP20x  [![Build Status](https://travis-ci.com/Seeed-Studio/Grove_Barometer_HP20x.svg?branch=master)](https://travis-ci.com/Seeed-Studio/Grove_Barometer_HP20x)
------------
![](https://raw.githubusercontent.com/SeeedDocument/Grove-Barometer-High-Accuracy/master/img/Grove-Barometer-High-Accuracy.jpg)

[Grove - Barometer (High-Accuracy)](https://www.seeedstudio.com/Grove-Barometer-%28High-Accuracy%29-p-1865.html)


  This is a driver for Grove_barometer HP20x(high accuracy and waterproof).
  DataSheet of this sensor:(https://raw.githubusercontent.com/SeeedDocument/Grove-Barometer-High-Accuracy/master/res/HP206C_Datasheet.pdf)

### Usage
    1.Git clone this resp to your arduino IDE's lib directory.
	2.Open the demo "HP20x_dev"

More information please visit [wiki page](http://wiki.seeedstudio.com/Grove-Barometer-High-Accuracy/).

----

This software is written by Oliver Wang (long.wang@seeedstudio.com) for seeed studio<br>
and is licensed under [The MIT License](http://opensource.org/licenses/mit-license.php). Check License.txt for more information.<br>


Seeed Studio is an open hardware facilitation company based in Shenzhen, China. <br>
Benefiting from local manufacture power and convenient global logistic system, <br>
we integrate resources to serve new era of innovation. Seeed also works with <br>
global distributors and partners to push open hardware movement.<br>

[![Bitdeli Badge](https://d2weczhvl823v0.cloudfront.net/Seeed-Studio/mesh_bee/trend.png)](https://bitdeli.com/free "Bitdeli Badge")

[![Analytics](https://ga-beacon.appspot.com/UA-46589105-3/Mesh_Bee)](https://github.com/igrigorik/ga-beacon)

